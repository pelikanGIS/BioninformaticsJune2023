#consts
number_of_tissues <- 19
length_threshold <-  100

#directories
parent.dir <-  getwd()
setwd(parent.dir)

library(WGCNA);

data1 <- read.csv('ordered_tissues.csv')

#for(i in 1:nrow(data1)) {       # for-loop over columns
#  longstring <- data1[i,1]
#  shortstring <- substr(longstring, 1, length_threshold)
#  print(longstring)
#  print(shortstring)
#  data1[i,1] <- shortstring 
  
#}

#tissue.dir <- 'Tissues'
#setwd(tissue.dir)

#setwd('Raw')
#cc = list.files()
#print(cc)
#print(cc[2])
matrix_name = "sk_residual_matrix_w_const.csv"
sample_name = "sk_samples_as_dummies.csv"

chunk1 <-function(matrix_n) {
  # Display the current working directory
  #getwd();
  # If necessary, change the path below to the directory where the data files are stored. 
  # "." means current directory. On Windows use a forward slash / instead of the usual \.
  #workingDir = ".";
  #setwd(workingDir); 
  # Load the WGCNA package
  #library(WGCNA);
  # The following setting is important, do not omit.
  options(stringsAsFactors = FALSE);
  #Read in the female liver data set
  #mData <- read.csv();
  b <-read.csv(matrix_n);
  # Take a quick look at what is in the data set:
  dim(b);
  names(b);
  print("NO!!!")
  
  datExpr = b
  return(datExpr)
  
}

chunk7 <- function(samples_phen) {
  
  
  
  
  pplusData <- read.csv(samples_phen)
  dim(c)
  names(c)
  
  # remove columns that hold information we do not need.
  pTraits = pplusData[, c(1:9)];
  dim(pTraits)
  names(pTraits)
  
  # Form a data frame analogous to expression data that will hold the clinical traits.
  
  #femaleSamples = rownames(datExpr);
  #traitRows = match(femaleSamples, allTraits$Mice);
  #datTraits = allTraits[traitRows, -1];
  #rownames(datTraits) = allTraits[traitRows, 1];
  
  collectGarbage();
  
  return (pTraits)
  
  
}

chunk9 <- function(datExpr,pTraits) {
  save(datExpr, pTraits, file = "merged.RData")
}




data1 <- read.csv('ordered_tissues.csv')

for(i in 1:nrow(data1)) {       # for-loop over columns
  longstring <- data1[i,1]
  shortstring <- substr(longstring, 1, length_threshold)
  print(longstring)
  print(shortstring)
  data1[i,1] <- shortstring 
  
}
setwd(parent.dir)
setwd(tissue.dir)


for(i in 1:number_of_tissues) {       # for-loop over columns
  spec.tissue.dir <-  data1[i,1]
  print(i)
  print( spec.tissue.dir)
  setwd(spec.tissue.dir)
  setwd('Raw')
  print(list.files())
  result_matrix <- chunk1(matrix_name)
  result_sample <- chunk7(sample_name)
  chunk9(result_matrix,result_sample)
  
  print(list.files())
  setwd(parent.dir)
  
  setwd(tissue.dir)
  
  
}
setwd(parent.dir)


print(parent.dir )

#tissue.dir <- 'Tissues'
#setwd(tissue.dir)


#fahrenheit_to_celsius <- function(temp_F, value_to_repeat) {
#  temp_C <- (temp_F - 32) * 5 / 9
#  for(var in 1:value_to_repeat)
#  {
#    print(var)
#  }
#  
#  return(temp_C)
#}

#temp.C = fahrenheit_to_celsius(98.6,44)